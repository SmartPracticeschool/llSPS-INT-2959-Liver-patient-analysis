import requests

url = 'http://localhost:5000/results'
r = requests.post(url,json={'Age':56,'Gender':1,'Total_Bilirubin':1,'Direct_Bilirubin':1,'Alkaline_Phosphotase':187,'Alamine_Aminotransferase':16,
'Aspartate_Aminotransferase':18,'Total_Protiens':7,'Albumin':3,'Albumin_and_Globulin_Ratio':1})

print(r.json())
